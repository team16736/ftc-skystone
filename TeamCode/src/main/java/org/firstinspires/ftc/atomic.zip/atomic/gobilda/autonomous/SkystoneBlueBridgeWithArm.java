package org.firstinspires.ftc.atomic.gobilda.autonomous;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.ColorSensor;

import org.firstinspires.ftc.atomic.gobilda.actions.ArmElbowGripperActions;
import org.firstinspires.ftc.atomic.gobilda.actions.DriveWheelActions;
import org.firstinspires.ftc.atomic.gobilda.utilities.ConfigConstants;

/**
 * Purpose:
 * 1. Identify Skystone on Blue Quarry
 * 2. Deliver to the other side of the Blue bridge
 * 3. Park by the BridgeBlue
 *
 * Sensors must be attached to one of the I2C ports
 */
//START AT FIRST HOLE FROM THE RIGHT OF THE FRAME
@Autonomous(name = "Skystone BLUE Bridge With Arm", group = "GoBilda")


public class SkystoneBlueBridgeWithArm extends HelperAction {
    private ArmElbowGripperActions armActions = null;
    @Override
    public void runOpMode() {


        right_sensor = hardwareMap.get(ColorSensor.class, ConfigConstants.RIGHT_COLOR);
        right_sensor.enableLed(true);

        left_sensor = hardwareMap.get(ColorSensor.class, ConfigConstants.LEFT_COLOR); // NOT USED
        left_sensor.enableLed(false);

        DriveWheelActions driveActions = new DriveWheelActions(telemetry, hardwareMap);
        armActions = new ArmElbowGripperActions(telemetry, hardwareMap);
        waitForStart();


        // Step 1: Lift arm, Open elbow and grabber
        armUpAndStop(armActions, 0.4, 0.05);
        sleep(500);////////////
        elbowCompletelyOpen(armActions);
        grabberCompletelyOpen(armActions);




        // Step 1: Move FORWARD
        driveActions.applySensorSpeed = true;// we have altered the speed for the forwards movement
        drive_ForwardAndStop(driveActions, SPEED*2, 0.34 );
        sleep(500);

        // Step --> detect skystone using sensor
        foundStone = isThisSkystone(right_sensor, hsvValues);
        telemetry.update();
        double distanceSecondBlock = 0.0;
        // If stone is found, the collect it and deliver it
        if (foundStone) {

            telemetry.addData("Found black block: ", "1");
            telemetry.update();

            sleep(250);///////
            distanceSecondBlock = 2.0;
            collectStoneAndDeliverBlueSide(driveActions, distanceSecondBlock);

        } else {

            strafe_RightAndStop(driveActions, SPEED, 0.4);
            sleep(250);///////
            foundStone = isThisSkystone(right_sensor, hsvValues);

            if (foundStone) {

                telemetry.addData("Found black block: ", "2");
                telemetry.update();

                sleep(250);//////
                distanceSecondBlock = 2.7;
                collectStoneAndDeliverBlueSide(driveActions, distanceSecondBlock);

            } else {

                telemetry.addData("Found black block: ", "3");
                telemetry.update();

                strafe_RightAndStop(driveActions, SPEED, 0.4);
                sleep(500);/////////////////////
                distanceSecondBlock = 3.0;
                collectStoneAndDeliverBlueSide(driveActions, distanceSecondBlock);
            }
        }

        //Step 9: Move backwards to park under bridge
        drive_ReverseAndStop(driveActions, SPEED, distanceSecondBlock);
        foundStone = false;


        //Turn OFF the sensor LED
        right_sensor.enableLed(false);
        left_sensor.enableLed(false);
        driveActions.applySensorSpeed = false;// we have altered the speed for the forwards movement

        telemetry.addData("Mission complete!! ", " yeet ");
        telemetry.update();
        sleep(300);
    }

    /**
     * This method will collect stone and deliver.
     * This method can be used again for 2nd stone.. collect and deliver
     */
    private void collectStoneAndDeliverBlueSide(DriveWheelActions wheelActions, double distance) {

        //Step 2: if detect black block; Strafe RIGHT
        strafe_RightAndStop(wheelActions,SPEED,0.15);//changed
        sleep(500);

        //Step 3 : lower arm down to block
        armDownAndStop(armActions, 0.2, 0.05);
        sleep(500);

        //Step 4: grab block
        grabberCompletelyClosed(armActions);
        sleep(500);

        //Step 5: drive BACKWARDS to align with the bridge
        drive_ReverseAndStop(wheelActions, SPEED, 0.2);
        sleep(500);

        //Step 6: turn LEFT towards the bridge
        spin_LeftAndStop(wheelActions, SPEED, 0.7);
        sleep(400);
        

        //Step 7: drive FORWARD towards the bridge
        drive_ForwardAndStop(wheelActions, SPEED, distance);

        //Step 8: let go of block
        grabberCompletelyOpen(armActions);
    }

}