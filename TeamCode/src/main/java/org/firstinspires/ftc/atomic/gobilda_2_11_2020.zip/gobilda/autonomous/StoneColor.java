package org.firstinspires.ftc.atomic.gobilda.autonomous;

public class StoneColor {

    public boolean stone_1 = false;
    public boolean stone_2 = false;
    public boolean stone_3 = false;
    public boolean stone_4 = false;
    public boolean stone_5 = false;
    public boolean stone_6 = false;

    public boolean isStone_1() {
        return stone_1;
    }

    public void setStone_1(boolean stone_1) {
        this.stone_1 = stone_1;
    }

    public boolean isStone_2() {
        return stone_2;
    }

    public void setStone_2(boolean stone_2) {
        this.stone_2 = stone_2;
    }

    public boolean isStone_3() {
        return stone_3;
    }

    public void setStone_3(boolean stone_3) {
        this.stone_3 = stone_3;
    }

    public boolean isStone_4() {
        return stone_4;
    }

    public void setStone_4(boolean stone_4) {
        this.stone_4 = stone_4;
    }

    public boolean isStone_5() {
        return stone_5;
    }

    public void setStone_5(boolean stone_5) {
        this.stone_5 = stone_5;
    }

    public boolean isStone_6() {
        return stone_6;
    }

    public void setStone_6(boolean stone_6) {
        this.stone_6 = stone_6;
    }
}
